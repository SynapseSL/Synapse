﻿namespace Synapse.Patches.SynapsePatches.Item
{
    internal static class InventoryPatches
    {
        //[HarmonyPrefix]
        //[HarmonyPatch(typeof(Inventory), nameof(Inventory.UserCode_TargetRefreshItems))]
        //TODO:
        //RefreshItems
    }
}
