﻿using System;
using System.Linq;
using HarmonyLib;
using Synapse.Api;

namespace Synapse.Patches.SynapsePatches
{
    [HarmonyPatch(typeof(HitboxIdentity), nameof(HitboxIdentity.CheckFriendlyFire))]
    internal static class ShootPermissionPatch
    {
        private static bool Prefix(bool __result,ReferenceHub attacker, ReferenceHub victim, bool ignoreConfig = false)
        {
            try
            {
                var shooter = attacker.GetPlayer();
                var target = victim.GetPlayer();

                __result = true;

                if (Map.Get.Round.RoundEnded && Server.Get.Configs.synapseConfiguration.AutoFF)
                    return false;

                if(shooter.Team == Team.RIP || target.Team == Team.RIP)
                {
                    __result = false;
                }
                else if (shooter.CustomRole == null && target.CustomRole == null)
                {
                    if (shooter.Team == Team.SCP && target.Team == Team.SCP) __result = false;

                    var ff = Server.Get.FF;
                    if (ignoreConfig)
                        ff = true;

                    else if (!ff) __result = shooter.Faction != target.Faction;
                }
                else
                {
                    if (shooter.CustomRole != null)
                    {
                        if (shooter.CustomRole.GetFriendsID().Any(x => x == target.TeamID))
                        {
                            __result = false;
                            shooter.GiveTextHint(Server.Get.Configs.synapseTranslation.ActiveTranslation.sameTeam);
                        }
                    }
                    if (target.CustomRole != null)
                    {
                        if (target.CustomRole.GetFriendsID().Any(x => x == shooter.TeamID))
                        {
                            __result = false;
                            shooter.GiveTextHint(Server.Get.Configs.synapseTranslation.ActiveTranslation.sameTeam);
                        }
                    }
                }

                Server.Get.Events.Player.InvokePlayerDamagePermissions(target, shooter, ref __result);

                return false;
            }
            catch(Exception e)
            {
                Synapse.Api.Logger.Get.Error($"Synapse-API: GetShootPermission  failed!!\n{e}\nStackTrace:\n{e.StackTrace}");
                __result = true;
                return true;
            }
        }
    }
}
