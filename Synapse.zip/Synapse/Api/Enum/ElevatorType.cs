namespace Synapse.Api.Enum
{
    public enum ElevatorType
    {
        None,
        GateA,
        GateB,
        ElALeft,
        ElARight,
        ElBLeft,
        ElBRight,
        Nuke,
        Scp049,
    }
}
