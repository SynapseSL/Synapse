﻿namespace Synapse.Api.Enum
{
    public enum ItemState
    {
        Destroyed,
        Despawned,
        Inventory,
        Map
    }
}
