﻿namespace Synapse.Api.Enum
{
    public enum WeaponType
    {
        COM15,
        Project90,
        E11SR,
        MP7,
        Logicer,
        USP,
    }
}
