﻿namespace Synapse.Api.Enum
{
    public enum MovementDirection
    {
        Stop,
        Forward,
        BackWards,
        Right,
        Left
    }
}
