﻿namespace Synapse.Api.Enum
{
    public enum WorkstationState : byte
    {
        Offline,
        BootingUp,
        ShuttingDown,
        Online
    }
}
