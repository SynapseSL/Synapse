﻿namespace Synapse.Api.Enum
{
    public enum ScpAttackType
    {
        Scp173_Snap = 0,
        Scp106_Grab = 3,
        Scp049_Touch = 5,
        Scp096_Tear = 9,
        Scp0492_Scratch = 10,
        Scp939_Bite = 16,
    }
}
