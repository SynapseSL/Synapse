﻿namespace Synapse.Api.Enum
{
    public enum Recontain079Status
    {
        Initialize,
        Start,
        Finished
    }
}
