﻿namespace Synapse.Api.Enum
{
    public enum AmmoType
    {
        Ammo12gauge = 13,
        Ammo556x45 = 16,
        Ammo44cal = 21,
        Ammo762x39,
        Ammo9x19
    }
}
