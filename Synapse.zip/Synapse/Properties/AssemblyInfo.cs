﻿using System.Reflection;

[assembly: AssemblyTitle("Synapse")]
[assembly: AssemblyDescription("Synapse-ModdingFramework")]
[assembly: AssemblyCompany("Synapse-DevTeam")]
[assembly: AssemblyProduct("Synapse")]
[assembly: AssemblyCopyright("Copyright © Synapse-DevTeam 2021")]
[assembly: AssemblyVersion("2.7.0.0")]
[assembly: AssemblyFileVersion("2.7.0.0")]