﻿using System.Reflection;

[assembly: AssemblyTitle("SynapseLoader")]
[assembly: AssemblyDescription("Synapse-Loader")]
[assembly: AssemblyCompany("Synapse-DevTeam")]
[assembly: AssemblyProduct("SynapseLaoder")]
[assembly: AssemblyCopyright("Copyright © Synapse-DevTeam 2020")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]